# AI Cat (Forge 1.20.1)

Adds a tame "AI Cat" mob (spawn egg in the Spawn Eggs creative tab) that uses
the vanilla cat model/textures for a cute look with zero extra art assets.

Talk to it from the normal chat box: any message containing **"cat"** or
**"แคท"** is sent to the Groq API, and Cat's reply is shown in chat as
`Cat: ...` and (optionally) spoken out loud via your OS's text-to-speech.

## Setup
1. Get a free API key at https://console.groq.com/keys
2. Build the mod once (see below) so `config/aicat-client.toml` is generated,
   or just launch the game once with the mod installed.
3. Open `config/aicat-client.toml` and paste your key into `groqApiKey`.
   You can also change `groqModel`, `systemPrompt`, and turn `enableSpeech`
   off if you don't want spoken replies.

## Build
1. Install JDK 17 and have internet access.
2. From this folder: `./gradlew build` (or `gradlew.bat build` on Windows).
3. Output jar: `build/libs/aicat-1.0.0.jar`.
4. Drop it in your Forge 1.20.1 `mods` folder alongside `fpsboost` (they're
   fully independent — install either one alone or both together).

## Notes / limitations
- Text-to-speech shells out to the OS's own TTS (Windows Speech, macOS
  `say`, or `espeak`/`spd-say` on Linux). If none is installed, Cat just
  won't speak — the chat text still appears.
- The chat trigger only reacts to messages you type locally; it doesn't
  read other players' messages.
- The API key is stored in plain text in the config file — don't share that
  file or upload it publicly.
