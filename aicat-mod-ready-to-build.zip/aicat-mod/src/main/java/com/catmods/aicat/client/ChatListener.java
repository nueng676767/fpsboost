package com.catmods.aicat.client;

import com.catmods.aicat.config.AiCatConfig;
import com.catmods.aicat.groq.GroqClient;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "aicat", value = Dist.CLIENT)
public class ChatListener {

    @SubscribeEvent
    public static void onClientChat(ClientChatEvent event) {
        String message = event.getMessage();
        if (message == null || message.isBlank()) return;

        String lower = message.toLowerCase();
        boolean triggeredEnglish = lower.contains("cat");
        boolean triggeredThai = AiCatConfig.ENABLE_THAI_TRIGGER.get() && message.contains("\u0e41\u0e04\u0e17");

        if (!triggeredEnglish && !triggeredThai) return;

        // Let the normal chat message still send to the server/other players.
        // We just additionally ask Groq and print/speak Cat's reply locally.
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.displayClientMessage(
                    Component.literal("Cat: ").withStyle(ChatFormatting.LIGHT_PURPLE)
                            .append(Component.translatable("aicat.thinking").withStyle(ChatFormatting.GRAY)),
                    false);
        }

        GroqClient.askAsync(message,
                reply -> mc.execute(() -> {
                    if (mc.player == null) return;
                    Component catLine = Component.literal("Cat: ").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD)
                            .append(Component.literal(reply).withStyle(ChatFormatting.WHITE));
                    mc.player.displayClientMessage(catLine, false);
                    if (AiCatConfig.ENABLE_SPEECH.get()) {
                        TextToSpeech.speak(reply);
                    }
                }),
                error -> mc.execute(() -> {
                    if (mc.player == null) return;
                    mc.player.displayClientMessage(
                            Component.literal("Cat: ").withStyle(ChatFormatting.LIGHT_PURPLE)
                                    .append(Component.translatable("aicat.error").withStyle(ChatFormatting.RED)),
                            false);
                }));
    }
}
