package com.catmods.aicat.client;

import com.catmods.aicat.entity.ModEntities;
import net.minecraft.client.renderer.entity.CatRenderer;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "aicat", bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // Reuse vanilla's own cute cat model + all its texture variants —
        // AiCatEntity extends Cat so CatRenderer works out of the box.
        event.registerEntityRenderer(ModEntities.AI_CAT.get(), CatRenderer::new);
    }
}
