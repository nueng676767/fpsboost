package com.catmods.aicat.client;

import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

/**
 * Very small "speaks the reply out loud" helper. There is no built-in
 * cross-platform TTS in the JDK, so this shells out to whatever the host OS
 * already provides. If none is available it silently does nothing (the chat
 * message is still shown, so nothing is lost).
 */
public class TextToSpeech {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "aicat-tts");
        t.setDaemon(true);
        return t;
    });

    public static void speak(String text) {
        if (text == null || text.isBlank()) return;
        String safe = text.replace("\"", "'").replace("\n", " ");
        EXECUTOR.submit(() -> {
            try {
                String os = System.getProperty("os.name", "").toLowerCase();
                ProcessBuilder pb;
                if (os.contains("win")) {
                    String ps = "Add-Type -AssemblyName System.speech; " +
                            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; " +
                            "$s.Speak(\"" + safe + "\");";
                    pb = new ProcessBuilder("powershell", "-NoProfile", "-Command", ps);
                } else if (os.contains("mac")) {
                    pb = new ProcessBuilder("say", safe);
                } else {
                    // Linux: try espeak-ng, fall back to spd-say
                    pb = new ProcessBuilder("bash", "-c",
                            "command -v espeak-ng >/dev/null 2>&1 && espeak-ng \"" + safe + "\" " +
                            "|| command -v espeak >/dev/null 2>&1 && espeak \"" + safe + "\" " +
                            "|| command -v spd-say >/dev/null 2>&1 && spd-say \"" + safe + "\"");
                }
                pb.redirectErrorStream(true);
                Process process = pb.start();
                process.waitFor();
            } catch (Exception ignored) {
                // No TTS engine available on this system; fail silently.
            }
        });
    }
}
