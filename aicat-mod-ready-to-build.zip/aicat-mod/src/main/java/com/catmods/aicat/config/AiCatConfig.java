package com.catmods.aicat.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class AiCatConfig {
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.ConfigValue<String> GROQ_API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> GROQ_MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> SYSTEM_PROMPT;
    public static final ForgeConfigSpec.BooleanValue ENABLE_SPEECH;
    public static final ForgeConfigSpec.BooleanValue ENABLE_THAI_TRIGGER;

    static {
        BUILDER.push("AI Cat Settings");

        GROQ_API_KEY = BUILDER
                .comment("Your Groq API key. Get one at https://console.groq.com/keys",
                        "Never share this file or commit it to a public repo.")
                .define("groqApiKey", "PUT-YOUR-GROQ-API-KEY-HERE");

        GROQ_MODEL = BUILDER
                .comment("Groq model id, e.g. llama-3.3-70b-versatile")
                .define("groqModel", "llama-3.3-70b-versatile");

        SYSTEM_PROMPT = BUILDER
                .comment("Personality/instructions given to the AI cat")
                .define("systemPrompt",
                        "You are Cat (\u0e41\u0e04\u0e17), a playful and friendly cat companion living inside Minecraft. " +
                        "Keep replies short (1-3 sentences), warm, a little cheeky, and occasionally add a cat sound like 'meow~'. " +
                        "You can reply in Thai or English depending on what the player used.");

        ENABLE_SPEECH = BUILDER
                .comment("Whether Cat should speak its replies out loud using the OS text-to-speech engine")
                .define("enableSpeech", true);

        ENABLE_THAI_TRIGGER = BUILDER
                .comment("Also trigger Cat when the message contains the Thai word \u0e41\u0e04\u0e17")
                .define("enableThaiTrigger", true);

        BUILDER.pop();
        SPEC = BUILDER.build();
    }
}
