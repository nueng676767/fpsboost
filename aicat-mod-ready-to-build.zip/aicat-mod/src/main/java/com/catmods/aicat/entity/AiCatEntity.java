package com.catmods.aicat.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.level.Level;

/**
 * A cat that extends the vanilla Cat entity so it automatically gets the
 * built-in cute cat model + all vanilla textures/variants (tabby, tuxedo,
 * siamese, etc.) and animations for free, with no custom model/texture work
 * required. This is the entity players summon and talk to as "Cat"/"\u0e41\u0e04\u0e17".
 */
public class AiCatEntity extends Cat {
    public AiCatEntity(EntityType<? extends Cat> type, Level level) {
        super(type, level);
        this.setTame(true);
        this.setPersistenceRequired();
    }
}
