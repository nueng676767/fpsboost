package com.catmods.aicat.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, "aicat");
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, "aicat");

    public static final RegistryObject<EntityType<AiCatEntity>> AI_CAT = ENTITY_TYPES.register("ai_cat",
            () -> EntityType.Builder.of(AiCatEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.7F)
                    .clientTrackingRange(8)
                    .build("aicat:ai_cat"));

    public static final RegistryObject<Item> AI_CAT_SPAWN_EGG = ITEMS.register("ai_cat_spawn_egg",
            () -> new net.minecraft.world.item.ForgeSpawnEggItem(AI_CAT, 0x2b2b2b, 0xffa500,
                    new Item.Properties()));

    public static void register(IEventBus bus) {
        ENTITY_TYPES.register(bus);
        ITEMS.register(bus);
    }
}
