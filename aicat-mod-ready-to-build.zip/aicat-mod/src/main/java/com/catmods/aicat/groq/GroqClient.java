package com.catmods.aicat.groq;

import com.catmods.aicat.config.AiCatConfig;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Minimal Groq chat-completions client. Uses only the JDK's built in
 * HttpClient and a small hand-rolled JSON escaper/extractor so the mod has
 * zero extra dependencies to shade.
 */
public class GroqClient {

    private static final String ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    /**
     * Sends the player's message to Groq and calls back on a background thread
     * with either the reply text or an error message.
     */
    public static void askAsync(String playerMessage, Consumer<String> onSuccess, Consumer<String> onError) {
        String apiKey = AiCatConfig.GROQ_API_KEY.get();
        if (apiKey == null || apiKey.isBlank() || apiKey.equals("PUT-YOUR-GROQ-API-KEY-HERE")) {
            onError.accept("Missing Groq API key in config/aicat-client.toml");
            return;
        }

        String body = "{"
                + "\"model\":\"" + escape(AiCatConfig.GROQ_MODEL.get()) + "\","
                + "\"messages\":[" 
                + "{\"role\":\"system\",\"content\":\"" + escape(AiCatConfig.SYSTEM_PROMPT.get()) + "\"},"
                + "{\"role\":\"user\",\"content\":\"" + escape(playerMessage) + "\"}"
                + "],"
                + "\"temperature\":0.8,"
                + "\"max_tokens\":200"
                + "}";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(ENDPOINT))
                .timeout(Duration.ofSeconds(20))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();

        HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() != 200) {
                        onError.accept("Groq API error " + response.statusCode() + ": " + trim(response.body()));
                        return;
                    }
                    String content = extractContent(response.body());
                    if (content == null) {
                        onError.accept("Could not parse Groq response");
                    } else {
                        onSuccess.accept(content);
                    }
                })
                .exceptionally(ex -> {
                    onError.accept("Network error talking to Groq: " + ex.getMessage());
                    return null;
                });
    }

    private static String trim(String s) {
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }

    private static String escape(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

    // Pulls the first "content":"..." value out of the chat-completions JSON
    // without needing a full JSON library.
    private static final Pattern CONTENT_PATTERN = Pattern.compile("\"content\":\"((?:[^\"\\\\]|\\\\.)*)\"");

    private static String extractContent(String json) {
        Matcher m = CONTENT_PATTERN.matcher(json);
        String last = null;
        while (m.find()) {
            last = m.group(1);
        }
        if (last == null) return null;
        return unescape(last);
    }

    private static String unescape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char next = s.charAt(i + 1);
                switch (next) {
                    case 'n': sb.append('\n'); i++; break;
                    case 'r': sb.append('\r'); i++; break;
                    case 't': sb.append('\t'); i++; break;
                    case '"': sb.append('"'); i++; break;
                    case '\\': sb.append('\\'); i++; break;
                    case 'u':
                        if (i + 5 < s.length()) {
                            String hex = s.substring(i + 2, i + 6);
                            sb.append((char) Integer.parseInt(hex, 16));
                            i += 5;
                        }
                        break;
                    default: sb.append(next); i++;
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
